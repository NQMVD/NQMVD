local class = require "lib.middleclass"

function newpos(x, y)
	return { x=x, y=y }
end

lines = 2
adding = 3

PIN = class("PIN")
PIN.static.PINID = 0
PIN.static.generateNewPINID = function()
	PIN.static.PINID = PIN.static.PINID+1
	return PIN.static.PINID
end
function PIN:initialize()
	self.id = PIN.generateNewPINID()
	self.state = false
end

INPUTPIN = class("INPUTPIN", PIN)
function INPUTPIN:initialize()
	PIN.initialize(self)
end

OUTPUTPIN = class("OUTPUTPIN", PIN)
function OUTPUTPIN:initialize()
	PIN.initialize(self)
end


GATE = class("GATE")
GATE.static.GATEID = 1000
GATE.static.generateNewGATEID = function()
	GATE.static.GATEID = GATE.static.GATEID+1
	return GATE.static.GATEID
end
GATE.static.size = { width=9, height=14, scale=7 }
GATE.static.getWidth = function() return GATE.size.width*GATE.size.scale end
GATE.static.getHeight = function() return GATE.size.height*GATE.size.scale end

function GATE:initialize(x, y)
	self.pos = newpos(x, y)
	self.id = GATE.generateNewGATEID()
	self.state = false
	self.inputpins = Collection:new()
	self.inputpins:append(INPUTPIN())
	self.inputpins:append(INPUTPIN())
	self.outputpin = OUTPUTPIN()
end

function GATE:draw()
	-- green or red
	if self.state then love.graphics.setColor(0.2, 0.4, 0.2)
	else love.graphics.setColor(0.4, 0.2, 0.2) end
	-- base rectangle
	love.graphics.rectangle("fill", self.pos.x, self.pos.y, GATE.getWidth(), GATE.getHeight())
	local inputpincount = self.inputpins:count()
	local spacing = GATE.getHeight()/(3+inputpincount)
	local pinwidth = GATE.getWidth()/(GATE.size.width/3)

	-- input pins, lines and circles
	for i=1,inputpincount do
		love.graphics.setLineWidth(2)
		love.graphics.setColor(0.5, 0.5, 0.5)
		love.graphics.line(
			self.pos.x,
			self.pos.y + spacing*i,
			self.pos.x - pinwidth,
			self.pos.y + spacing*i
		)
		love.graphics.setColor(0, 0, 0)
		love.graphics.circle("fill", self.pos.x - pinwidth, self.pos.y + spacing*i, GATE.size.scale-1)
		love.graphics.setLineWidth(1)
		love.graphics.setColor(1, 1, 1)
		love.graphics.circle("line", self.pos.x - pinwidth, self.pos.y + spacing*i, GATE.size.scale-1)
	end

	-- output pin, line and circle
	love.graphics.setLineWidth(2)
	love.graphics.setColor(0.5, 0.5, 0.5)
	love.graphics.line(
		self.pos.x + GATE.getWidth(),
		self.pos.y + (GATE.getHeight()/2),
		self.pos.x + GATE.getWidth() + pinwidth,
		self.pos.y + (GATE.getHeight()/2)
	)
	love.graphics.setColor(0, 0, 0)
	love.graphics.circle("fill", self.pos.x + GATE.getWidth() + pinwidth, self.pos.y + (GATE.getHeight()/2), GATE.size.scale-1)
	love.graphics.setLineWidth(1)
	love.graphics.setColor(1, 1, 1)
	love.graphics.circle("line", self.pos.x + GATE.getWidth() + pinwidth, self.pos.y + (GATE.getHeight()/2), GATE.size.scale-1)

	-- base rectangle border
	love.graphics.setColor(1, 1, 1)
	love.graphics.setLineWidth(1)
	love.graphics.rectangle("line", self.pos.x, self.pos.y, GATE.getWidth(), GATE.getHeight())
end

function GATE:update()
	self.pos.x, self.pos.y = love.mouse.getPosition()
end


AND = class("AND", GATE)
function AND:initialize(x, y)
	GATE.initialize(self, x, y)
end

TEST = class("TEST", GATE)
function TEST:initialize(x, y)
	GATE.initialize(self, x, y)
end

function TEST:draw()
	-- green or red
	if self.state then love.graphics.setColor(0.2, 0.4, 0.2)
	else love.graphics.setColor(0.4, 0.2, 0.2) end
	-- base rectangle
	love.graphics.rectangle("fill", self.pos.x, self.pos.y, GATE.getWidth(), GATE.getHeight())
	local inputpincount = self.inputpins:count()
	local spacing = GATE.getHeight()/(adding+lines)
	local pinwidth = GATE.getWidth()/(GATE.size.width/3)

	-- input pins, lines and circles
	for i=1,lines do
		love.graphics.setLineWidth(2)
		love.graphics.setColor(0.5, 0.5, 0.5)
		love.graphics.line(
			self.pos.x,
			self.pos.y + spacing*i,
			self.pos.x - pinwidth,
			self.pos.y + spacing*i
		)
		love.graphics.setColor(0, 0, 0)
		love.graphics.circle("fill", self.pos.x - pinwidth, self.pos.y + spacing*i, GATE.size.scale-1)
		love.graphics.setLineWidth(1)
		love.graphics.setColor(1, 1, 1)
		love.graphics.circle("line", self.pos.x - pinwidth, self.pos.y + spacing*i, GATE.size.scale-1)
	end

	-- base rectangle border
	love.graphics.setColor(1, 1, 1)
	love.graphics.setLineWidth(1)
	love.graphics.rectangle("line", self.pos.x, self.pos.y, GATE.getWidth(), GATE.getHeight())
end

-- NAND
-- OR
-- NOR
-- XOR
-- XNOR
-- NOT
-- INPUT
-- OUTPUT
