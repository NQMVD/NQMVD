io.stdout:setvbuf("no")
inspect = require "lib.inspect"
Collection = require "lib.collections"
usingSublime = false

function prinspect(...) print(inspect(...)) end
function printf(...) print(string.format(...)) end

function ioclear() -- ANSI clear screen (call once to clear)
	if not usingSublime then
		io.write("\027[2J")
	end
end

function iohome() -- ANSI home cursor (call to update)
	if not usingSublime then
		io.write("\027[H")
	end
end

function nfc(num)
    return tostring(num):reverse():gsub("%d%d%d", "%1,"):reverse():gsub("^,", "")
end

function eo(a, b, c) -- entweder oder lol
	if c then return a
	else return b end
end

function eucdist(x1, y1, x2, y2)
    return math.sqrt((x2-x1)^2 + (y2-y1)^2)
end

function mandist(x1, y1, x2, y2)
    return math.abs(x2 - x1) + math.abs(y2 - y1)
end

function map(value, start1, stop1, start2, stop2)
     return start2 + (stop2 - start2) * ((value - start1) / (stop1 - start1));
end

function constrain(value, start, stop)
    if value > stop then return stop
    elseif value < start then return start
    else return value end
end


timeRecordsTable = collect{}

function startTimeRecord(name_)
	local firstIndex = timeRecordsTable:search(function(key, value) return value.name == name_ end)
	if type(firstIndex) == "number" then
		timeRecordsTable.table[firstIndex].duration = 0
		timeRecordsTable.table[firstIndex].endTime = 0
		timeRecordsTable.table[firstIndex].startTime = love.timer.getTime()
	else
		timeRecordsTable:append{ name=name_, startTime=love.timer.getTime(), endTime=0, duration=0 }
	end
end

function stopTimeRecord(name_)
	local time = love.timer.getTime()
	local firstIndex = timeRecordsTable:search(function(key, value) return value.name == name_ end)
	if type(firstIndex) == "number" then
		timeRecordsTable.table[firstIndex].endTime = time
		timeRecordsTable.table[firstIndex].duration = time - timeRecordsTable.table[firstIndex].startTime
	end
end

function printTimeRecords()
	timeRecordsTable:each(function(key, value) printf("'%s' took %.3fms\n", value.name, value.duration*1000) end)
end

printHistory = collect{}
isCleared = false

function printc(msg_) -- print compressed, no spam, NOT WORKING IN THE SUBLIME CONSOLE LOL
	if usingSublime then
		local firstIndex = printHistory:search(function(key, value) return value.msg == msg_ end)
		if type(firstIndex) ~= "number" then
			printHistory:append{ msg=msg_ }
			printf("%s\n", msg_)
		end
	else
		local firstIndex = printHistory:search(function(key, value) return value.msg == msg_ end)
		local refresh = false
		if type(firstIndex) == "number" then
			local c = printHistory.table[firstIndex].count
			if c < 100 then
				printHistory.table[firstIndex].count = c+1
				refresh = true
			end
		else
			printHistory:append{ msg=msg_, count=1 }
		end
		if refresh then
			if not isCleared then ioclear() print() isCleared=true end
			iohome()
			printHistory:each(function(key, value) printf("%s(%d)\n", value.msg, value.count) end)
		end
	end
end

