---@diagnostic disable: unused-local

--[[
	variables: camelCase starting low
	functions: camelCase starting low
	classes:   UPPERCASE
	variables in classes:        lowercase
	static variables in classes: UPPERCASE
--]]

--==============================================================[ IMPORTS ]===================================================================--

require "lib.noahsutils"
require "classes"
usingSublime = true

--=============================================================[ VARIABLES ]==================================================================--

local t1, t2 = AND(100, 100), TEST(500, 100)

--===========================================================[ MAIN FUNCTIONS ]===============================================================--

function love.load()
	love.graphics.setFont(love.graphics.newFont("fonts/main.ttf", 20))
end

function love.update(dt)
	if love.mouse.isDown(1) then
		t2:update()
	end
end

function love.draw()

	t2:draw()

	love.graphics.setColor(1, 1, 1)
	love.graphics.print("FPS: " .. tostring(love.timer.getFPS()).." | Height: "..tostring(GATE.static.size.height).." | Lines: "..tostring(lines).." | Add: "..tostring(adding))
end

function love.quit()

end

--==========================================================[ INPUT FUNCTIONS ]===============================================================--

function love.mousepressed(x, y, button) end

function love.mousereleased(x, y, button) end

function love.wheelmoved(dx, dy)
	if love.keyboard.isDown("lshift") then
		adding = adding+dy
	elseif love.keyboard.isDown("lctrl") then
		GATE.static.size.height = GATE.static.size.height + dy
	else
		lines = lines + dy
	end
end

function love.keypressed(key, unicode) end

--==========================================================[ CUSTOM FUNCTIONS ]==============================================================--
