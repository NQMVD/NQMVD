local class = require "lib.middleclass"
local lume = require "lib.lume"

function newpos(x, y)
	return { x=x, y=y }
end

function love.graphics.printCentered(text, x, y)
	local font = love.graphics.getFont()
	love.graphics.print(text, x - (font:getWidth(text)/2), y - (font:getHeight()/2))
end

PIN = class("PIN")
PIN.static.PINID = 0
PIN.static.generateNewPINID = function()
	PIN.static.PINID = PIN.static.PINID+1
	return PIN.static.PINID
end
function PIN:initialize()
	self.id = PIN.generateNewPINID()
	self.state = false
	self.pos = newpos(0, 0)
end

INPUTPIN = class("INPUTPIN", PIN)
function INPUTPIN:initialize()
	PIN.initialize(self)
end

OUTPUTPIN = class("OUTPUTPIN", PIN)
function OUTPUTPIN:initialize()
	PIN.initialize(self)
end


BOARDOBJECT = class("BOARDOBJECT")
function BOARDOBJECT:initialize(x, y, type)
	self.pos = newpos(x, y)
	self.type = type
end

GATE = class("GATE", BOARDOBJECT)
GATE.static.GATEID = 1000
GATE.static.generateNewGATEID = function()
	GATE.static.GATEID = GATE.static.GATEID+1
	return GATE.static.GATEID
end
GATE.static.size = { width=9, height=14, scale=7, space = 10 }
GATE.static.getWidth = function() return GATE.size.width*GATE.size.scale end
GATE.static.getHeight = function() return GATE.size.height*GATE.size.scale end

function GATE:initialize(x, y, inputpincount)
	BOARDOBJECT.initialize(self, x, y, GATE.name)
	self.inputpincount = inputpincount or 2
	self.id = GATE.generateNewGATEID()
	self.state = false
	self.inputpins = Collection:new()
	for i=1,self.inputpincount do
		self.inputpins:append(INPUTPIN())
	end	
	self.outputpin = OUTPUTPIN()
end

function GATE:update() end -- override this

function GATE:drawMe() end -- override this

function GATE:isInside(x, y)
	local width = GATE.getWidth()
	local height = self:height()
	return x >= self.pos.x and x <= self.pos.x + width and y >= self.pos.y and y <= self.pos.y + height
end

function GATE:getInputPinIDAt(x, y)
	local pinwidth = GATE.getWidth()/(GATE.size.width/3)
	local pinx = self.pos.x - pinwidth
	local piny = self.pos.y + (GATE.size.space*2)
	for i=1,self.inputpincount do
		if lume.distance(pinx, piny, x, y, false) < 10 then
			return self.inputpins:get(i).id
		end
		piny = piny + (GATE.size.space*3)
	end
	return nil
end
function GATE:getOutputPinIDAt(x, y)
	local pinwidth = GATE.getWidth()/(GATE.size.width/3)
	local pinx = self.pos.x + GATE.getWidth() + pinwidth
	local piny = self.pos.y + self:height()/2
	if lume.distance(pinx, piny, x, y, false) < 10 then
		return self.outputpin.id
	end
	return nil
end

function GATE:getInputPinByID(id)
	for i=1,self.inputpincount do
		if self.inputpins:get(i).id == id then
			return self.inputpins:get(i)
		end
	end
	return nil
end
function GATE:getOutputPinByID(id)
	if self.outputpin.id == id then
		return self.outputpin
	end
	return nil
end

function GATE:height()
	return GATE.size.space * (4+(3*(self.inputpincount-1)))
end

function GATE:draw()
	-- green or red
	if self.state then love.graphics.setColor(0.2, 0.4, 0.2)
	else love.graphics.setColor(0.4, 0.2, 0.2) end
	-- base rectangle
	local height = self:height()
	love.graphics.rectangle("fill", self.pos.x, self.pos.y, GATE.getWidth(), height)

	local pinwidth = GATE.getWidth()/(GATE.size.width/3)
	-- input pins, lines and circles
	for i=1,self.inputpincount do
		local ypos = self.pos.y + (GATE.size.space*2) + ((GATE.size.space*3)*(i-1))
		love.graphics.setLineWidth(2)
		love.graphics.setColor(0.5, 0.5, 0.5)
		love.graphics.line(
			self.pos.x, ypos,
			self.pos.x - pinwidth, ypos
		)
		love.graphics.setColor(0, 0, 0)
		love.graphics.circle("fill", self.pos.x - pinwidth, ypos, GATE.size.scale-1)
		love.graphics.setLineWidth(1)
		love.graphics.setColor(1, 1, 1)
		love.graphics.circle("line", self.pos.x - pinwidth, ypos, GATE.size.scale-1)
		self.inputpins:get(i).pos = newpos(self.pos.x - pinwidth, ypos)
	end

	-- output pin, line and circle
	love.graphics.setLineWidth(2)
	love.graphics.setColor(0.5, 0.5, 0.5)
	love.graphics.line(
		self.pos.x + GATE.getWidth(),
		self.pos.y + (height/2),
		self.pos.x + GATE.getWidth() + pinwidth,
		self.pos.y + (height/2)
	)
	love.graphics.setColor(0, 0, 0)
	love.graphics.circle("fill", self.pos.x + GATE.getWidth() + pinwidth, self.pos.y + (height/2), GATE.size.scale-1)
	love.graphics.setLineWidth(1)
	love.graphics.setColor(1, 1, 1)
	love.graphics.circle("line", self.pos.x + GATE.getWidth() + pinwidth, self.pos.y + (height/2), GATE.size.scale-1)
	self.outputpin.pos = newpos(self.pos.x + GATE.getWidth() + pinwidth, self.pos.y + (height/2))

	-- base rectangle border
	love.graphics.setColor(1, 1, 1)
	love.graphics.setLineWidth(1)
	love.graphics.rectangle("line", self.pos.x, self.pos.y, GATE.getWidth(), height)

	-- Gate Type dependant drawing
	self:drawMe()
end


AND = class("AND", GATE)
function AND:initialize(x, y, inputpincount)
	GATE.initialize(self, x, y, inputpincount)
end
function AND:drawMe()
	love.graphics.setColor(1, 1, 1)
	love.graphics.printCentered(AND.name, self.pos.x + (GATE.getWidth()/2), self.pos.y + (self:height()/2))
end
function AND:update()
	local newstate = true
	for i=1,self.inputpincount do
		newstate = newstate and self.inputpins:get(i).state
	end
	self.state = newstate
	self.outputpin.state = self.state
end

NAND = class("NAND", GATE)
function NAND:initialize(x, y, inputpincount)
	GATE.initialize(self, x, y, inputpincount)
end
function NAND:drawMe()
	love.graphics.setColor(1, 1, 1)
	love.graphics.printCentered(NAND.name, self.pos.x + (GATE.getWidth()/2), self.pos.y + (self:height()/2))
end
function NAND:update()
	local newstate = true
	for i=1,self.inputpincount do
		newstate = newstate and self.inputpins:get(i).state
	end
	self.state = not newstate
	self.outputpin.state = self.state
end

OR = class("OR", GATE)
function OR:initialize(x, y, inputpincount)
	GATE.initialize(self, x, y, inputpincount)
end
function OR:drawMe()
	love.graphics.setColor(1, 1, 1)
	love.graphics.printCentered(OR.name, self.pos.x + (GATE.getWidth()/2), self.pos.y + (self:height()/2))
end
function OR:update()
	local newstate = false
	for i=1,self.inputpincount do
		newstate = newstate or self.inputpins:get(i).state
	end
	self.state = newstate
	self.outputpin.state = self.state
end

NOR = class("NOR", GATE)
function NOR:initialize(x, y, inputpincount)
	GATE.initialize(self, x, y, inputpincount)
end
function NOR:drawMe()
	love.graphics.setColor(1, 1, 1)
	love.graphics.printCentered(NOR.name, self.pos.x + (GATE.getWidth()/2), self.pos.y + (self:height()/2))
end
function NOR:update()
	local newstate = false
	for i=1,self.inputpincount do
		newstate = newstate or self.inputpins:get(i).state
	end
	self.state = not newstate
	self.outputpin.state = self.state
end

XOR = class("XOR", GATE)
function XOR:initialize(x, y, inputpincount)
	GATE.initialize(self, x, y, inputpincount)
end
function XOR:drawMe()
	love.graphics.setColor(1, 1, 1)
	love.graphics.printCentered(XOR.name, self.pos.x + (GATE.getWidth()/2), self.pos.y + (self:height()/2))
end
function XOR:update()
	local newstate = false
	for i=1,self.inputpincount do
		if self.inputpins:get(i).state then newstate = not newstate end
	end
	self.state = newstate
	self.outputpin.state = self.state
end

XNOR = class("XNOR", GATE)
function XNOR:initialize(x, y, inputpincount)
	GATE.initialize(self, x, y, inputpincount)
end
function XNOR:drawMe()
	love.graphics.setColor(1, 1, 1)
	love.graphics.printCentered(XNOR.name, self.pos.x + (GATE.getWidth()/2), self.pos.y + (self:height()/2))
end
function XNOR:update()
	local newstate = true
	for i=1,self.inputpincount do
		if self.inputpins:get(i).state then newstate = not newstate end
	end
	self.state = newstate
	self.outputpin.state = self.state
end

NOT = class("NOT", GATE)
function NOT:initialize(x, y, inputpincount)
	GATE.initialize(self, x, y, inputpincount)
end
function NOT:drawMe()
	love.graphics.setColor(1, 1, 1)
	love.graphics.printCentered(NOT.name, self.pos.x + (GATE.getWidth()/2), self.pos.y + (self:height()/2))
end
function NOT:update()
	local newstate = true
	for i=1,self.inputpincount do
		if self.inputpins:get(i).state then newstate = false break end
	end
	self.state = newstate
	self.outputpin.state = self.state
end

PERIPHERAL = class("PERIPHERAL", BOARDOBJECT)
PERIPHERAL.static.PERIPHERALID = 2000
PERIPHERAL.static.generateNewPERIPHERALID = function()
	PERIPHERAL.static.PERIPHERALID = PERIPHERAL.static.PERIPHERALID+1
	return PERIPHERAL.static.PERIPHERALID
end
PERIPHERAL.static.size = { width=9, height=6, scale=7 }
PERIPHERAL.static.getWidth = function() return PERIPHERAL.size.width*PERIPHERAL.size.scale end
PERIPHERAL.static.getHeight = function() return PERIPHERAL.size.height*PERIPHERAL.size.scale end

function PERIPHERAL:initialize(x, y)
	BOARDOBJECT.initialize(self, x, y, PERIPHERAL.name)
	self.id = PERIPHERAL.generateNewPERIPHERALID()
	self.state = false
end

function PERIPHERAL:update() end

function PERIPHERAL:set(state)
	self.state = state
end
function PERIPHERAL:flip() 
	self.state = not self.state
end

function PERIPHERAL:drawMe() end

function PERIPHERAL:isInside(x, y)
	local width = PERIPHERAL.getWidth()
	local height = PERIPHERAL.getHeight()
	return x >= self.pos.x and x <= self.pos.x + width and y >= self.pos.y and y <= self.pos.y + height
end

function PERIPHERAL:draw()
	-- green or red
	if self.state then love.graphics.setColor(0.2, 0.4, 0.2)
	else love.graphics.setColor(0.4, 0.2, 0.2) end
	-- base rectangle
	love.graphics.rectangle("fill", self.pos.x, self.pos.y, PERIPHERAL.getWidth(), PERIPHERAL.getHeight())

	-- base rectangle border
	love.graphics.setColor(1, 1, 1)
	love.graphics.setLineWidth(1)
	love.graphics.rectangle("line", self.pos.x, self.pos.y, PERIPHERAL.getWidth(), PERIPHERAL.getHeight())

	self:drawMe()
end


INPUT = class("INPUT", PERIPHERAL)
function INPUT:initialize(x, y)
	PERIPHERAL.initialize(self, x, y)
	self.outputpin = OUTPUTPIN()
end

function INPUT:getPinIDAt(x, y)
	local pinwidth = PERIPHERAL.getWidth()/(PERIPHERAL.size.width/3)
	local pinx = self.pos.x + PERIPHERAL.getWidth() + pinwidth
	local piny = self.pos.y + PERIPHERAL.getHeight()/2
	if lume.distance(pinx, piny, x, y, false) < 10 then
		return self.outputpin.id, "output"
	end
	return nil
end

function INPUT:getPinByID(id)
	if self.outputpin.id == id then return self.outputpin end
	return nil
end

function INPUT:update() end

function INPUT:drawMe()
	-- output pin
	local pinwidth = PERIPHERAL.getWidth()/(PERIPHERAL.size.width/3)
	local xpos = self.pos.x + PERIPHERAL.getWidth()
	local ypos = self.pos.y + (PERIPHERAL.getHeight()/2)

	love.graphics.setLineWidth(2)
	love.graphics.setColor(0.5, 0.5, 0.5)
	love.graphics.line(xpos, ypos, xpos + pinwidth, ypos)
	love.graphics.setColor(0, 0, 0)
	love.graphics.circle("fill", xpos + pinwidth, ypos, GATE.size.scale-1)
	love.graphics.setLineWidth(1)
	love.graphics.setColor(1, 1, 1)
	love.graphics.circle("line", xpos + pinwidth, ypos, GATE.size.scale-1)
	self.outputpin.pos = newpos(xpos + pinwidth, ypos)

	-- state
	local pad = 5
	love.graphics.setColor(0, 0, 0, 0.5)
	love.graphics.rectangle("fill", self.pos.x+pad + (self.state and PERIPHERAL.getWidth()/2-pad or 0), self.pos.y+pad, PERIPHERAL.getWidth()/2-pad, PERIPHERAL.getHeight()-pad*2)
end


OUTPUT = class("OUTPUT", PERIPHERAL)
function OUTPUT:initialize(x, y)
	PERIPHERAL.initialize(self, x, y)
	self.inputpin = INPUTPIN()
end

function OUTPUT:getPinIDAt(x, y)
	local pinwidth = GATE.getWidth()/(GATE.size.width/3)
	local pinx = self.pos.x - pinwidth
	local piny = self.pos.y + (PERIPHERAL.getHeight()/2)
	if lume.distance(pinx, piny, x, y, false) < 10 then
		return self.inputpin.id, "input"
	end
	return nil
end

function OUTPUT:getPinByID(id)
	if self.inputpin.id == id then return self.inputpin end
	return nil
end

function OUTPUT:update()
	self.state = self.inputpin.state
end

function OUTPUT:drawMe()
	love.graphics.setColor(1, 1, 1)
	love.graphics.printCentered(OUTPUT.name, self.pos.x + (PERIPHERAL.getWidth()/2), self.pos.y + (PERIPHERAL.getHeight()/2))

	-- input pin
	local pinwidth = PERIPHERAL.getWidth()/(PERIPHERAL.size.width/3)
	local xpos = self.pos.x
	local ypos = self.pos.y + (PERIPHERAL.getHeight()/2)

	love.graphics.setLineWidth(2)
	love.graphics.setColor(0.5, 0.5, 0.5)
	love.graphics.line(xpos, ypos, xpos - pinwidth, ypos)
	love.graphics.setColor(0, 0, 0)
	love.graphics.circle("fill", xpos - pinwidth, ypos, GATE.size.scale-1)
	love.graphics.setLineWidth(1)
	love.graphics.setColor(1, 1, 1)
	love.graphics.circle("line", xpos - pinwidth, ypos, GATE.size.scale-1)
	self.inputpin.pos = newpos(xpos - pinwidth, ypos)
end