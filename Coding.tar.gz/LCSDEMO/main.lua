--==============================================================[ imports ]===================================================================--

io.stdout:setvbuf("no")
local lume = require("lib.lume")
local inspect = require("lib.inspect")
local gui = require('gui'):new()
local Class = require("lib.class")

--=============================================================[ variables ]==================================================================--

local lg = love.graphics
local lm = love.mouse

local font = love.graphics.newFont("assets/univga16.ttf", 16, "none")
font:setFilter("nearest")
local fontHeight = font:getHeight()

local contextMenu = nil
local showContextMenu = false
local pad = 10
local buttonSize = { w = 60, h = 40}

local gateSize = { width = 100, height = 50 }
local gates = {}

local buttonAmount = 9
local buttonOffsets = {
	AND    = { x=pad,                y=fontHeight },
	OR     = { x=pad+buttonSize.w,   y=fontHeight },
	NOT    = { x=pad+buttonSize.w*2, y=fontHeight },
	NAND   = { x=pad,                y=fontHeight+buttonSize.h },
	NOR    = { x=pad+buttonSize.w,   y=fontHeight+buttonSize.h },
	XOR    = { x=pad+buttonSize.w*2, y=fontHeight+buttonSize.h },
	XNOR   = { x=pad+buttonSize.w*3, y=fontHeight+buttonSize.h },
	INPUT  = { x=pad,                y=fontHeight+buttonSize.h*2 },
	OUTPUT = { x=pad+buttonSize.w,   y=fontHeight+buttonSize.h*2 },
}

local isConnectingCable = false
local firstConnectionPin = {
	id=0,
	pos={ x=0, y=0 },
	gateindex=0
}
local connections = {}

local menu = nil
local menuEnum = {
	menu = 1, board = 2, options = 3
}
local menuState = menuEnum.menu

--==========================================================[ custom functions ]==============================================================--

local function line(a, b)
	lg.line(a.x, a.y, b.x, b.y)
end

local function bounds(x, y, w, h)
    local b = {}
	b.x, b.y, b.w, b.h = x, y, w, h
	return b
end

local function posi(x, y)
    local p = {}
	p.x, p.y = x, y
	return p
end

function mandist(a, b)
    return math.abs(b.x - a.x) + math.abs(b.y - a.y)
end

function mouseInRange(pos, range)
	local x, y = lm.getPosition()
	return mandist(posi(x, y), pos) <= range
end

function mouseInBox(bounds)
	local x, y = lm.getPosition()
	return x >= bounds.x and x <= bounds.x+bounds.w and y >= bounds.y and y <= bounds.y+bounds.h
end

currentID = 0
generateNewID = function()
	currentID = currentID+1
	return currentID
end

local function connectPins(secondConnectionPin)
	table.insert(connections, {
		output = { id=firstConnectionPin.id, pos=firstConnectionPin.pos, gateindex=firstConnectionPin.gateindex },
		input = { id=secondConnectionPin.id, pos=secondConnectionPin.pos, gateindex=secondConnectionPin.gateindex }
	})
	isConnectingCable = false
	-- print(inspect(connections))
end

local function drawGateTwoPins(p, state)
	if state then lg.setColor(0.2, 0.4, 0.2)
	else lg.setColor(0.4, 0.2, 0.2)	end
	lg.rectangle("fill", p.x, p.y, gateSize.width, gateSize.height)		
	love.graphics.setLineWidth(3)
	lg.line(p.x, p.y + (gateSize.height/4), p.x - (gateSize.width/5), p.y + (gateSize.height/4))
	lg.line(p.x, p.y + (gateSize.height/4*3), p.x - (gateSize.width/5), p.y + (gateSize.height/4*3))		
	lg.line(p.x + gateSize.width, p.y + (gateSize.height/2), p.x + gateSize.width + (gateSize.width/5), p.y + (gateSize.height/2))

	lg.setColor(0, 0, 0)
	lg.circle("fill", p.x - (gateSize.width/5), p.y + (gateSize.height/4), 5)
	lg.circle("fill", p.x - (gateSize.width/5), p.y + (gateSize.height/4*3), 5)
	lg.circle("fill", p.x + gateSize.width + (gateSize.width/5), p.y + (gateSize.height/2), 5)

	lg.setColor(1, 1, 1)		
	love.graphics.setLineWidth(1)
	lg.rectangle("line", p.x, p.y, gateSize.width, gateSize.height)
	lg.circle("line", p.x - (gateSize.width/5), p.y + (gateSize.height/4), 5)
	lg.circle("line", p.x - (gateSize.width/5), p.y + (gateSize.height/4*3), 5)
	lg.circle("line", p.x + gateSize.width + (gateSize.width/5), p.y + (gateSize.height/2), 5)
end

local function drawGateOnePin(p, state)
	if state then lg.setColor(0.2, 0.4, 0.2)
	else lg.setColor(0.4, 0.2, 0.2)	end
	lg.rectangle("fill", p.x, p.y, gateSize.width, gateSize.height)		
	love.graphics.setLineWidth(3)
	lg.line(p.x, p.y + (gateSize.height/2), p.x - (gateSize.width/5), p.y + (gateSize.height/2))
	lg.line(p.x + gateSize.width, p.y + (gateSize.height/2), p.x + gateSize.width + (gateSize.width/5), p.y + (gateSize.height/2))

	lg.setColor(0, 0, 0)
	lg.circle("fill", p.x - (gateSize.width/5), p.y + (gateSize.height/2), 5)
	lg.circle("fill", p.x + gateSize.width + (gateSize.width/5), p.y + (gateSize.height/2), 5)

	lg.setColor(1, 1, 1)		
	love.graphics.setLineWidth(1)
	lg.rectangle("line", p.x, p.y, gateSize.width, gateSize.height)
	lg.circle("line", p.x - (gateSize.width/5), p.y + (gateSize.height/2), 5)
	lg.circle("line", p.x + gateSize.width + (gateSize.width/5), p.y + (gateSize.height/2), 5)
end

--==========================================================[ custom classes ]==============================================================--


AND = Class{
    init = function(self, x, y, index)
        self.pos = { x=x, y=y }
        self.index = index
        self.state = false
        self.firstInputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x - (gateSize.width/5), y = self.pos.y + (gateSize.height/4) },
        	state=false
        }
        self.secondInputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x - (gateSize.width/5), y = self.pos.y + (gateSize.height/4*3) },
        	state=false
        }
        self.outputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x + gateSize.width + (gateSize.width/5), y = self.pos.y + (gateSize.height/2) },
        	state=false
        }
    end,

	draw = function(self)
		drawGateTwoPins(self.pos, self:getState())
		if mouseInRange(posi(self.firstInputPin.pos.x, self.firstInputPin.pos.y), 8)
			or mouseInRange(posi(self.secondInputPin.pos.x, self.secondInputPin.pos.y), 8)
			or mouseInRange(posi(self.outputPin.pos.x, self.outputPin.pos.y), 8) then
			lg.circle("fill", lm.getX(), lm.getY(), 5)
		end
		lg.print(self.firstInputPin.id, self.firstInputPin.pos.x-5, self.firstInputPin.pos.y-20)
		lg.print(self.secondInputPin.id, self.secondInputPin.pos.x-5, self.secondInputPin.pos.y-20)
		lg.print(self.outputPin.id, self.outputPin.pos.x-5, self.outputPin.pos.y-20)
        lg.print("AND",
			(self.pos.x + gateSize.width / 2) - (font:getWidth("AND")/2), 
			(self.pos.y + gateSize.height / 2) - (fontHeight/2)
		)
	end,

	getState = function(self)
		return self.firstInputPin.state and self.secondInputPin.state
	end,

	setState = function(self, id, state)
		if self.firstInputPin.id == id then
			self.firstInputPin.state = state

		elseif self.secondInputPin.id == id then
			self.secondInputPin.state = state

		end
	end,

	checkMouse = function(self)
		self:checkPins()
	end,

	checkPins = function(self)
		if isConnectingCable then
			if     mouseInRange(self.firstInputPin.pos, 8) then
				connectPins{ id=self.firstInputPin.id, pos=self.firstInputPin.pos, gateindex=self.index }

			elseif mouseInRange(self.secondInputPin.pos, 8) then
				connectPins{ id=self.secondInputPin.id, pos=self.secondInputPin.pos, gateindex=self.index }

			elseif mouseInRange(self.outputPin.pos, 8) then
				connectPins{ id=self.outputPin.id, pos=self.outputPin.pos, gateindex=self.index}

			end
		else
			if mouseInRange(self.firstInputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.firstInputPin.id
				firstConnectionPin.pos = self.firstInputPin.pos
				firstConnectionPin.gateindex = self.index
			elseif mouseInRange(self.secondInputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.secondInputPin.id
				firstConnectionPin.pos = self.secondInputPin.pos
				firstConnectionPin.gateindex = self.index
			elseif mouseInRange(self.outputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.outputPin.id
				firstConnectionPin.pos = self.outputPin.pos
				firstConnectionPin.gateindex = self.index
			end
		end
	end,
}

NAND = Class{
    init = function(self, x, y, index)
        self.pos = { x=x, y=y }
        self.index = index
        self.state = false
        self.firstInputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x - (gateSize.width/5), y = self.pos.y + (gateSize.height/4) },
        	state=false
        }
        self.secondInputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x - (gateSize.width/5), y = self.pos.y + (gateSize.height/4*3) },
        	state=false
        }
        self.outputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x + gateSize.width + (gateSize.width/5), y = self.pos.y + (gateSize.height/2) },
        	state=false
        }
    end,

	draw = function(self)
		drawGateTwoPins(self.pos, self:getState())
		if mouseInRange(posi(self.firstInputPin.pos.x, self.firstInputPin.pos.y), 8)
			or mouseInRange(posi(self.secondInputPin.pos.x, self.secondInputPin.pos.y), 8)
			or mouseInRange(posi(self.outputPin.pos.x, self.outputPin.pos.y), 8) then
			lg.circle("fill", lm.getX(), lm.getY(), 5)
		end
		lg.print(self.firstInputPin.id, self.firstInputPin.pos.x-5, self.firstInputPin.pos.y-20)
		lg.print(self.secondInputPin.id, self.secondInputPin.pos.x-5, self.secondInputPin.pos.y-20)
		lg.print(self.outputPin.id, self.outputPin.pos.x-5, self.outputPin.pos.y-20)
        lg.print("NAND",
			(self.pos.x + gateSize.width / 2) - (font:getWidth("NAND")/2), 
			(self.pos.y + gateSize.height / 2) - (fontHeight/2)
		)
	end,

	getState = function(self)
		return not (self.firstInputPin.state and self.secondInputPin.state)
	end,

	setState = function(self, id, state)
		if self.firstInputPin.id == id then
			self.firstInputPin.state = state

		elseif self.secondInputPin.id == id then
			self.secondInputPin.state = state

		end
	end,

	checkMouse = function(self)
		self:checkPins()
	end,

	checkPins = function(self)
		if isConnectingCable then
			if     mouseInRange(self.firstInputPin.pos, 8) then
				connectPins{ id=self.firstInputPin.id, pos=self.firstInputPin.pos, gateindex=self.index }

			elseif mouseInRange(self.secondInputPin.pos, 8) then
				connectPins{ id=self.secondInputPin.id, pos=self.secondInputPin.pos, gateindex=self.index }

			elseif mouseInRange(self.outputPin.pos, 8) then
				connectPins{ id=self.outputPin.id, pos=self.outputPin.pos, gateindex=self.index}

			end
		else
			if mouseInRange(self.firstInputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.firstInputPin.id
				firstConnectionPin.pos = self.firstInputPin.pos
				firstConnectionPin.gateindex = self.index
			elseif mouseInRange(self.secondInputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.secondInputPin.id
				firstConnectionPin.pos = self.secondInputPin.pos
				firstConnectionPin.gateindex = self.index
			elseif mouseInRange(self.outputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.outputPin.id
				firstConnectionPin.pos = self.outputPin.pos
				firstConnectionPin.gateindex = self.index
			end
		end
	end,
}

OR = Class{
    init = function(self, x, y, index)
        self.pos = { x=x, y=y }
        self.index = index
        self.state = false
        self.firstInputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x - (gateSize.width/5), y = self.pos.y + (gateSize.height/4) },
        	state=false
        }
        self.secondInputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x - (gateSize.width/5), y = self.pos.y + (gateSize.height/4*3) },
        	state=false
        }
        self.outputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x + gateSize.width + (gateSize.width/5), y = self.pos.y + (gateSize.height/2) },
        	state=false
        }
    end,

	draw = function(self)
		drawGateTwoPins(self.pos, self:getState())
		if mouseInRange(posi(self.firstInputPin.pos.x, self.firstInputPin.pos.y), 8)
			or mouseInRange(posi(self.secondInputPin.pos.x, self.secondInputPin.pos.y), 8)
			or mouseInRange(posi(self.outputPin.pos.x, self.outputPin.pos.y), 8) then
			lg.circle("fill", lm.getX(), lm.getY(), 5)
		end
		lg.print(self.firstInputPin.id, self.firstInputPin.pos.x-5, self.firstInputPin.pos.y-20)
		lg.print(self.secondInputPin.id, self.secondInputPin.pos.x-5, self.secondInputPin.pos.y-20)
		lg.print(self.outputPin.id, self.outputPin.pos.x-5, self.outputPin.pos.y-20)
        lg.print("OR",
			(self.pos.x + gateSize.width / 2) - (font:getWidth("OR")/2), 
			(self.pos.y + gateSize.height / 2) - (fontHeight/2)
		)
	end,

	getState = function(self)
		return self.firstInputPin.state or self.secondInputPin.state
	end,

	setState = function(self, id, state)
		if self.firstInputPin.id == id then
			self.firstInputPin.state = state

		elseif self.secondInputPin.id == id then
			self.secondInputPin.state = state
			
		end
	end,

	checkMouse = function(self)
		self:checkPins()
	end,

	checkPins = function(self)
		if isConnectingCable then
			if     mouseInRange(self.firstInputPin.pos, 8) then
				connectPins{ id=self.firstInputPin.id, pos=self.firstInputPin.pos, gateindex=self.index }

			elseif mouseInRange(self.secondInputPin.pos, 8) then
				connectPins{ id=self.secondInputPin.id, pos=self.secondInputPin.pos, gateindex=self.index }

			elseif mouseInRange(self.outputPin.pos, 8) then
				connectPins{ id=self.outputPin.id, pos=self.outputPin.pos, gateindex=self.index}

			end
		else
			if mouseInRange(self.firstInputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.firstInputPin.id
				firstConnectionPin.pos = self.firstInputPin.pos
				firstConnectionPin.gateindex = self.index
			elseif mouseInRange(self.secondInputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.secondInputPin.id
				firstConnectionPin.pos = self.secondInputPin.pos
				firstConnectionPin.gateindex = self.index
			elseif mouseInRange(self.outputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.outputPin.id
				firstConnectionPin.pos = self.outputPin.pos
				firstConnectionPin.gateindex = self.index
			end
		end
	end,
}

NOR = Class{
    init = function(self, x, y, index)
        self.pos = { x=x, y=y }
        self.index = index
        self.state = false
        self.firstInputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x - (gateSize.width/5), y = self.pos.y + (gateSize.height/4) },
        	state=false
        }
        self.secondInputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x - (gateSize.width/5), y = self.pos.y + (gateSize.height/4*3) },
        	state=false
        }
        self.outputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x + gateSize.width + (gateSize.width/5), y = self.pos.y + (gateSize.height/2) },
        	state=false
        }
    end,

	draw = function(self)
		drawGateTwoPins(self.pos, self:getState())
		if mouseInRange(posi(self.firstInputPin.pos.x, self.firstInputPin.pos.y), 8)
			or mouseInRange(posi(self.secondInputPin.pos.x, self.secondInputPin.pos.y), 8)
			or mouseInRange(posi(self.outputPin.pos.x, self.outputPin.pos.y), 8) then
			lg.circle("fill", lm.getX(), lm.getY(), 5)
		end
		lg.print(self.firstInputPin.id, self.firstInputPin.pos.x-5, self.firstInputPin.pos.y-20)
		lg.print(self.secondInputPin.id, self.secondInputPin.pos.x-5, self.secondInputPin.pos.y-20)
		lg.print(self.outputPin.id, self.outputPin.pos.x-5, self.outputPin.pos.y-20)
        lg.print("NOR",
			(self.pos.x + gateSize.width / 2) - (font:getWidth("NOR")/2), 
			(self.pos.y + gateSize.height / 2) - (fontHeight/2)
		)
	end,

	getState = function(self)
		return not (self.firstInputPin.state or self.secondInputPin.state)
	end,

	setState = function(self, id, state)
		if self.firstInputPin.id == id then
			self.firstInputPin.state = state

		elseif self.secondInputPin.id == id then
			self.secondInputPin.state = state
			
		end
	end,

	checkMouse = function(self)
		self:checkPins()
	end,

	checkPins = function(self)
		if isConnectingCable then
			if     mouseInRange(self.firstInputPin.pos, 8) then
				connectPins{ id=self.firstInputPin.id, pos=self.firstInputPin.pos, gateindex=self.index }

			elseif mouseInRange(self.secondInputPin.pos, 8) then
				connectPins{ id=self.secondInputPin.id, pos=self.secondInputPin.pos, gateindex=self.index }

			elseif mouseInRange(self.outputPin.pos, 8) then
				connectPins{ id=self.outputPin.id, pos=self.outputPin.pos, gateindex=self.index}

			end
		else
			if mouseInRange(self.firstInputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.firstInputPin.id
				firstConnectionPin.pos = self.firstInputPin.pos
				firstConnectionPin.gateindex = self.index
			elseif mouseInRange(self.secondInputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.secondInputPin.id
				firstConnectionPin.pos = self.secondInputPin.pos
				firstConnectionPin.gateindex = self.index
			elseif mouseInRange(self.outputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.outputPin.id
				firstConnectionPin.pos = self.outputPin.pos
				firstConnectionPin.gateindex = self.index
			end
		end
	end,
}

XOR = Class{
    init = function(self, x, y, index)
        self.pos = { x=x, y=y }
        self.index = index
        self.state = false
        self.firstInputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x - (gateSize.width/5), y = self.pos.y + (gateSize.height/4) },
        	state=false
        }
        self.secondInputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x - (gateSize.width/5), y = self.pos.y + (gateSize.height/4*3) },
        	state=false
        }
        self.outputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x + gateSize.width + (gateSize.width/5), y = self.pos.y + (gateSize.height/2) },
        	state=false
        }
    end,

	draw = function(self)
		drawGateTwoPins(self.pos, self:getState())
		if mouseInRange(posi(self.firstInputPin.pos.x, self.firstInputPin.pos.y), 8)
			or mouseInRange(posi(self.secondInputPin.pos.x, self.secondInputPin.pos.y), 8)
			or mouseInRange(posi(self.outputPin.pos.x, self.outputPin.pos.y), 8) then
			lg.circle("fill", lm.getX(), lm.getY(), 5)
		end
		lg.print(self.firstInputPin.id, self.firstInputPin.pos.x-5, self.firstInputPin.pos.y-20)
		lg.print(self.secondInputPin.id, self.secondInputPin.pos.x-5, self.secondInputPin.pos.y-20)
		lg.print(self.outputPin.id, self.outputPin.pos.x-5, self.outputPin.pos.y-20)
        lg.print("XOR",
			(self.pos.x + gateSize.width / 2) - (font:getWidth("XOR")/2), 
			(self.pos.y + gateSize.height / 2) - (fontHeight/2)
		)
	end,

	getState = function(self)
		return (self.firstInputPin.state and not self.secondInputPin.state) or (not self.firstInputPin.state and self.secondInputPin.state)
	end,

	setState = function(self, id, state)
		if self.firstInputPin.id == id then
			self.firstInputPin.state = state

		elseif self.secondInputPin.id == id then
			self.secondInputPin.state = state
			
		end
	end,

	checkMouse = function(self)
		self:checkPins()
	end,

	checkPins = function(self)
		if isConnectingCable then
			if     mouseInRange(self.firstInputPin.pos, 8) then
				connectPins{ id=self.firstInputPin.id, pos=self.firstInputPin.pos, gateindex=self.index }

			elseif mouseInRange(self.secondInputPin.pos, 8) then
				connectPins{ id=self.secondInputPin.id, pos=self.secondInputPin.pos, gateindex=self.index }

			elseif mouseInRange(self.outputPin.pos, 8) then
				connectPins{ id=self.outputPin.id, pos=self.outputPin.pos, gateindex=self.index}

			end
		else
			if mouseInRange(self.firstInputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.firstInputPin.id
				firstConnectionPin.pos = self.firstInputPin.pos
				firstConnectionPin.gateindex = self.index
			elseif mouseInRange(self.secondInputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.secondInputPin.id
				firstConnectionPin.pos = self.secondInputPin.pos
				firstConnectionPin.gateindex = self.index
			elseif mouseInRange(self.outputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.outputPin.id
				firstConnectionPin.pos = self.outputPin.pos
				firstConnectionPin.gateindex = self.index
			end
		end
	end,
}

XNOR = Class{
    init = function(self, x, y, index)
        self.pos = { x=x, y=y }
        self.index = index
        self.state = false
        self.firstInputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x - (gateSize.width/5), y = self.pos.y + (gateSize.height/4) },
        	state=false
        }
        self.secondInputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x - (gateSize.width/5), y = self.pos.y + (gateSize.height/4*3) },
        	state=false
        }
        self.outputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x + gateSize.width + (gateSize.width/5), y = self.pos.y + (gateSize.height/2) },
        	state=false
        }
    end,

	draw = function(self)
		drawGateTwoPins(self.pos, self:getState())
		if mouseInRange(posi(self.firstInputPin.pos.x, self.firstInputPin.pos.y), 8)
			or mouseInRange(posi(self.secondInputPin.pos.x, self.secondInputPin.pos.y), 8)
			or mouseInRange(posi(self.outputPin.pos.x, self.outputPin.pos.y), 8) then
			lg.circle("fill", lm.getX(), lm.getY(), 5)
		end
		lg.print(self.firstInputPin.id, self.firstInputPin.pos.x-5, self.firstInputPin.pos.y-20)
		lg.print(self.secondInputPin.id, self.secondInputPin.pos.x-5, self.secondInputPin.pos.y-20)
		lg.print(self.outputPin.id, self.outputPin.pos.x-5, self.outputPin.pos.y-20)
        lg.print("XOR",
			(self.pos.x + gateSize.width / 2) - (font:getWidth("XOR")/2), 
			(self.pos.y + gateSize.height / 2) - (fontHeight/2)
		)
	end,

	getState = function(self)
		return (self.firstInputPin.state and self.secondInputPin.state) or (not self.firstInputPin.state and not self.secondInputPin.state)
	end,

	setState = function(self, id, state)
		if self.firstInputPin.id == id then
			self.firstInputPin.state = state

		elseif self.secondInputPin.id == id then
			self.secondInputPin.state = state
			
		end
	end,

	checkMouse = function(self)
		self:checkPins()
	end,

	checkPins = function(self)
		if isConnectingCable then
			if     mouseInRange(self.firstInputPin.pos, 8) then
				connectPins{ id=self.firstInputPin.id, pos=self.firstInputPin.pos, gateindex=self.index }

			elseif mouseInRange(self.secondInputPin.pos, 8) then
				connectPins{ id=self.secondInputPin.id, pos=self.secondInputPin.pos, gateindex=self.index }

			elseif mouseInRange(self.outputPin.pos, 8) then
				connectPins{ id=self.outputPin.id, pos=self.outputPin.pos, gateindex=self.index}

			end
		else
			if mouseInRange(self.firstInputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.firstInputPin.id
				firstConnectionPin.pos = self.firstInputPin.pos
				firstConnectionPin.gateindex = self.index
			elseif mouseInRange(self.secondInputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.secondInputPin.id
				firstConnectionPin.pos = self.secondInputPin.pos
				firstConnectionPin.gateindex = self.index
			elseif mouseInRange(self.outputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.outputPin.id
				firstConnectionPin.pos = self.outputPin.pos
				firstConnectionPin.gateindex = self.index
			end
		end
	end,
}

NOT = Class{
    init = function(self, x, y, index)
        self.pos = { x=x, y=y }
        self.index = index
        self.state = false
        self.inputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x - (gateSize.width/5), y = self.pos.y + (gateSize.height/2) },
        	state=false
        }
        self.outputPin = {
        	id=generateNewID(),
        	pos={ x = self.pos.x + gateSize.width + (gateSize.width/5), y = self.pos.y + (gateSize.height/2) },
        	state=false
        }
    end,

	draw = function(self)
		drawGateOnePin(self.pos, self:getState())
		if mouseInRange(posi(self.inputPin.pos.x, self.inputPin.pos.y), 8)
			or mouseInRange(posi(self.outputPin.pos.x, self.outputPin.pos.y), 8) then
			lg.circle("fill", lm.getX(), lm.getY(), 5)
		end
		lg.print(self.inputPin.id, self.inputPin.pos.x-5, self.inputPin.pos.y-20)
		lg.print(self.outputPin.id, self.outputPin.pos.x-5, self.outputPin.pos.y-20)
        lg.print("NOT",
			(self.pos.x + gateSize.width / 2) - (font:getWidth("NOT")/2), 
			(self.pos.y + gateSize.height / 2) - (fontHeight/2)
		)
	end,

	getState = function(self)
		return not self.inputPin.state
	end,

	setState = function(self, id, state)
		self.inputPin.state = state
	end,

	checkMouse = function(self)
		self:checkPins()
	end,

	checkPins = function(self)
		if isConnectingCable then
			if     mouseInRange(self.inputPin.pos, 8) then
				connectPins{ id=self.inputPin.id, pos=self.inputPin.pos, gateindex=self.index }

			elseif mouseInRange(self.outputPin.pos, 8) then
				connectPins{ id=self.outputPin.id, pos=self.outputPin.pos, gateindex=self.index}

			end
		else
			if mouseInRange(self.inputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.inputPin.id
				firstConnectionPin.pos = self.inputPin.pos
				firstConnectionPin.gateindex = self.index
			elseif mouseInRange(self.outputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.outputPin.id
				firstConnectionPin.pos = self.outputPin.pos
				firstConnectionPin.gateindex = self.index
			end
		end
	end,
}

Input = Class{
    init = function(self, x, y, index)
        self.pos = { x=x, y=y }
        self.state = false
        self.index = index        
        self.outputPin = {
        	pos={ x = self.pos.x + gateSize.width + (gateSize.width/5), y = self.pos.y + (gateSize.height/2) }
        }
    end,

	draw = function(self)
		if self.state then
			lg.setColor(0.2, 0.4, 0.2)
		else
			lg.setColor(0.4, 0.2, 0.2)
		end
		lg.rectangle("fill", self.pos.x, self.pos.y, gateSize.width, gateSize.height)		
		love.graphics.setLineWidth(3)
		lg.line(self.pos.x + gateSize.width, self.pos.y + (gateSize.height/2), self.pos.x + gateSize.width + (gateSize.width/5), self.pos.y + (gateSize.height/2))

		lg.setColor(0, 0, 0)
		lg.circle("fill", self.pos.x + gateSize.width + (gateSize.width/5), self.pos.y + (gateSize.height/2), 5)

		lg.setColor(1, 1, 1)		
		love.graphics.setLineWidth(1)
		lg.rectangle("line", self.pos.x, self.pos.y, gateSize.width, gateSize.height)
		lg.circle("line", self.pos.x + gateSize.width + (gateSize.width/5), self.pos.y + (gateSize.height/2), 5)
		if mouseInRange(posi(self.outputPin.pos.x, self.outputPin.pos.y), 8) then
			lg.circle("fill", lm.getX(), lm.getY(), 8)
		end
        lg.print("Input", 
			(self.pos.x + gateSize.width / 2) - (font:getWidth("Input")/2), 
			(self.pos.y + gateSize.height / 2) - (fontHeight/2)
		)
	end,

	getState = function(self)
		return self.state
	end,

	setState = function(self, id, state) end,

	checkMouse = function(self)
		if mouseInBox(bounds(self.pos.x, self.pos.y, gateSize.width, gateSize.height)) then
			self.state = not self.state
		end
		self:checkPins()
	end,

	checkPins = function(self)
		if isConnectingCable then
			if mouseInRange(self.outputPin.pos, 8) then
				connectPins{id=self.outputPin.id, pos=self.outputPin.pos, gateindex=self.index, id=0 }
			end
		else
			if mouseInRange(self.outputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.outputPin.id
				firstConnectionPin.pos = self.outputPin.pos
				firstConnectionPin.gateindex = self.index
			end
		end
	end,
}

Output = Class{
    init = function(self, x, y, index)
        self.pos = { x=x, y=y }
        self.state = false
        self.index = index
        self.inputPin = {
        	pos={ x = self.pos.x - (gateSize.width/5), y = self.pos.y + (gateSize.height/2) }
        }        
    end,

	draw = function(self)
		if self.state then
			lg.setColor(0.2, 0.4, 0.2)
		else
			lg.setColor(0.4, 0.2, 0.2)
		end
		lg.rectangle("fill", self.pos.x, self.pos.y, gateSize.width, gateSize.height)		
		love.graphics.setLineWidth(3)
		lg.line(self.pos.x, self.pos.y + (gateSize.height/2), self.pos.x - (gateSize.width/5), self.pos.y + (gateSize.height/2))

		lg.setColor(0, 0, 0)
		lg.circle("fill", self.pos.x - (gateSize.width/5), self.pos.y + (gateSize.height/2), 5)

		lg.setColor(1, 1, 1)		
		love.graphics.setLineWidth(1)
		lg.rectangle("line", self.pos.x, self.pos.y, gateSize.width, gateSize.height)
		lg.circle("line", self.pos.x - (gateSize.width/5), self.pos.y + (gateSize.height/2), 5)
		if mouseInRange(posi(self.inputPin.pos.x, self.inputPin.pos.y), 8) then
			lg.circle("fill", lm.getX(), lm.getY(), 8)
		end
        lg.print("Output", 
			(self.pos.x + gateSize.width / 2) - (font:getWidth("Output")/2), 
			(self.pos.y + gateSize.height / 2) - (fontHeight/2)
		)
	end,

	getState = function(self)
		print("me shouldvt be culld")
		return false
	end,

	setState = function(self, id, state)
		self.state = state
	end,

	checkMouse = function(self)
		self:checkPins()
	end,

	checkPins = function(self)
		if isConnectingCable then
			if mouseInRange(self.inputPin.pos, 8) then
				connectPins{id=self.inputPin.id, pos=self.inputPin.pos, gateindex=self.index, id=0 }
			end
		else
			if mouseInRange(self.inputPin.pos, 8) then
				isConnectingCable = true
				firstConnectionPin.id = self.inputPin.id
				firstConnectionPin.pos = self.inputPin.pos
				firstConnectionPin.gateindex = self.index
			end
		end
	end,
}

--=========================================================[ default functions ]==============================================================--

function love.load()
	menu = gui:group("MENU", bounds(0, 0, lg.getWidth(), lg.getHeight()))
	menu.display = true
	local start = gui:button("Start", bounds(1920/2-150/2, 1080/2-50/2, 150, 50), menu)
    -- local options = gui:button("Options", bounds(10, 90, 100, 50), menu)

	start.click = function(this)
		menu.display = false
		menuState = menuEnum.board
	end
	-- options.click = function(this)
	-- 	menu.display = false
	-- 	menuState = menuEnum.options
	-- end

    -- optionsMenu = gui:group("Options", bounds(0, 0, lg.getWidth(), lg.getHeight()))
    -- optionsMenu.display = false
    -- local showFPS = gui:button("Show FPS", bounds(10, 30, 100, 50),optionsMenu)
    -- local FPSstate = false
    -- showFPS.click = function(this)
    --     FPSstate = not FPSstate
    -- end

	contextMenu = gui:group("Menu", bounds(100, 100, pad*2+buttonSize.w*4, pad*2+buttonSize.h*3))
	contextMenu.display = false


	local ANDButton = gui:button("AND", bounds(buttonOffsets.AND.x, buttonOffsets.AND.y, buttonSize.w, buttonSize.h), contextMenu)
	ANDButton.click = function(this)
		table.insert(gates, AND(contextMenu.absx, contextMenu.absy, #gates+1))
		showContextMenu = false
	end

	local ORButton = gui:button("OR", bounds(buttonOffsets.OR.x, buttonOffsets.OR.y, buttonSize.w, buttonSize.h), contextMenu)
	ORButton.click = function(this)
		table.insert(gates, OR(contextMenu.absx, contextMenu.absy, #gates+1))
		showContextMenu = false
	end

	local XORButton = gui:button("XOR", bounds(buttonOffsets.XOR.x, buttonOffsets.XOR.y, buttonSize.w, buttonSize.h), contextMenu)
	XORButton.click = function(this)
		table.insert(gates, XOR(contextMenu.absx, contextMenu.absy, #gates+1))
		showContextMenu = false
	end


	local NOTButton = gui:button("NOT", bounds(buttonOffsets.NOT.x, buttonOffsets.NOT.y, buttonSize.w, buttonSize.h), contextMenu)
	NOTButton.click = function(this)
		table.insert(gates, NOT(contextMenu.absx, contextMenu.absy, #gates+1))
		showContextMenu = false
	end

	local NANDButton = gui:button("NAND", bounds(buttonOffsets.NAND.x, buttonOffsets.NAND.y, buttonSize.w, buttonSize.h), contextMenu)
	NANDButton.click = function(this)
		table.insert(gates, NAND(contextMenu.absx, contextMenu.absy, #gates+1))
		showContextMenu = false
	end

	local NORButton = gui:button("NOR", bounds(buttonOffsets.NOR.x, buttonOffsets.NOR.y, buttonSize.w, buttonSize.h), contextMenu)
	NORButton.click = function(this)
		table.insert(gates, NOR(contextMenu.absx, contextMenu.absy, #gates+1))
		showContextMenu = false
	end

	local XNORButton = gui:button("XNOR", bounds(buttonOffsets.XNOR.x, buttonOffsets.XNOR.y, buttonSize.w, buttonSize.h), contextMenu)
	XNORButton.click = function(this)
		table.insert(gates, XNOR(contextMenu.absx, contextMenu.absy, #gates+1))
		showContextMenu = false
	end
	

	local INPUTButton = gui:button("INPUT", bounds(buttonOffsets.INPUT.x, buttonOffsets.INPUT.y, buttonSize.w, buttonSize.h), contextMenu)
	INPUTButton.click = function(this)
		table.insert(gates, Input(contextMenu.absx, contextMenu.absy, #gates+1))
		showContextMenu = false
	end	

	local OUTPUTButton = gui:button("OUTPUT", bounds(buttonOffsets.OUTPUT.x, buttonOffsets.OUTPUT.y, buttonSize.w, buttonSize.h), contextMenu)
	OUTPUTButton.click = function(this)
		table.insert(gates, Output(contextMenu.absx, contextMenu.absy, #gates+1))
		showContextMenu = false
	end
	-- contextMenu:verticaltile()

	gui:updatepositions()
end

function love.update(dt)
	if menuState == menuEnum.board then
        for _,connection in ipairs(connections) do
			local outputState = gates[connection.output.gateindex]:getState()
			gates[connection.input.gateindex]:setState(connection.input.id, outputState)
        end
    end
	gui:update(dt)
end

function love.draw()
	if menuState == menuEnum.board then
        for _,gate in ipairs(gates) do
            gate:draw()
        end

        for _,connection in ipairs(connections) do
        	line(connection.output.pos, connection.input.pos)
			lg.setColor(1,0,0)
			lg.circle("fill", connection.output.pos.x, connection.output.pos.y, 5)
			-- lg.print(tostring(connection.output.id), connection.output.pos.x+5, connection.output.pos.y+10)
			lg.setColor(0,0,1)
			lg.circle("fill", connection.input.pos.x, connection.input.pos.y, 5)
			-- lg.print(tostring(connection.input.id), connection.input.pos.x+5, connection.input.pos.y+10)
			lg.setColor(1,1,1)
        end

		if isConnectingCable then
			line(firstConnectionPin.pos, posi(lm.getX(), lm.getY()))
		end

		contextMenu.display = showContextMenu
    end
	gui:draw()

	if love.keyboard.isDown('f') then
		lg.setColor(1,1,1)
		lg.print("FPS: "..love.timer.getFPS(), 10, 10)
	end

end

function love.quit()

end

--==========================================================[ input functions ]===============================================================--

function love.mousepressed(x, y, button)
	if gui.hoverelement == nil and menuState == menuEnum.board then
		if button == 2 and not isConnectingCable then
			local lastPos = { x=contextMenu.absx, y=contextMenu.absy}
			showContextMenu = true
			contextMenu.absx = x
			contextMenu.absy = y
			for i,child in ipairs(contextMenu.children) do
				child.absx = child.absx + (x-lastPos.x)
				child.absy = child.absy + (y-lastPos.y)
			end
		elseif button == 1 and contextMenu.display == true then			
			showContextMenu = false
		end

		if button == 1 then
			for _,gate in ipairs(gates) do
				gate:checkMouse()
			end
		elseif button == 2 then
			isConnectingCable = false
		end
	end
    
	gui:mousepress(x, y, button)
end

function love.mousereleased(x, y, button)
	gui:mouserelease(x, y, button)
end

function love.keypressed(key, unicode)
	if key == "escape" then
		if menuState == menuEnum.board then
			menu.display = true
			menuState = menuEnum.menu
		else
			love.event.quit()
		end
	end

	if key == "delete" and #gates > 0 then
		if love.keyboard.isDown("lshift") then
			table.remove(connections, #connections)
		elseif love.keyboard.isDown("lctrl") then
			connections = {}
			gates = {}
		else
			for index,connection in ipairs(connections) do
	        	if connection.input.gateindex == #gates or connection.output.gateindex == #gates then
	        		table.remove(connections, index)
	        	end
	        end
			table.remove(gates, #gates)
	    end
	end
	gui:keypress(key)
end

function love.textinput(key)
	gui:textinput(key)
end