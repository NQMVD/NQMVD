function love.conf(t)
    t.window.usedpiscale = false
    t.window.width = 800
    t.window.height = 1000

    -- t.window.fullscreen = true

    t.modules.joystick = false
    t.modules.physics = false
end