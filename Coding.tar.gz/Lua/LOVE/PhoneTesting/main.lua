lg = love.graphics
height, width = lg.getDimensions()

showMouseCoords = false

buttons = {
    showMouseCoords = {
        text = "Show MouseCoords",
        x = 50, y = height-60, w = 150, h = 30,
        action = function() showMouseCoords = not showMouseCoords end
    }
}

function love.load()

end

function love.update(dt)

end

function love.draw()
    for _,b in pairs(buttons) do
        lg.rectangle("line", b.x, b.y, b.w, b.h)
        lg.print(b.text, b.x+5, b.y+5)
    end

    lg.print("Dimensions: " .. tostring(width) .. " x " .. tostring(height), 50, 100)
    if showMouseCoords then 
        lg.print("Mouse: " .. tostring(love.mouse.getX()) .. " | " .. tostring(love.mouse.getY()), 50, 120)
    end
end


function love.mousepressed( x, y, button, istouch, presses )
    for _,b in pairs(buttons) do
        if x > b.x and x < b.x+b.w and y > b.y and y < b.y+b.h then
            b.action()
        end
    end
end
