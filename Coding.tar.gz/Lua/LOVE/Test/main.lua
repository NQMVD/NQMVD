
-- Load some default values for our rectangle.
function love.load()
    x, y, w, h = 20, 140, 80, 20
    print(love.graphics.getWidth())
    print(love.graphics.getHeight())
end

-- Increase the size of the rectangle every frame.
function love.update(dt)
    if w < love.graphics.getWidth()-40 then
        w = w + 2
    end
    if h < love.graphics.getHeight()-40 then
        h = h + 2
    end
end

-- Draw a coloured rectangle.
function love.draw()
    love.graphics.setColor(0, 0.5, 0.2)
    love.graphics.rectangle("fill", x, y, w, h)

    love.graphics.setColor(1, 1, 1)
    love.graphics.print(love.timer.getFPS(), 20, 100)
end