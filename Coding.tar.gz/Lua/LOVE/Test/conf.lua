function love.conf(t)
    t.modules.joystick = false
    t.modules.physics = false
end