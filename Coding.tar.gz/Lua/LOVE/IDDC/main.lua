lg = love.graphics
height, width = lg.getDimensions()
textFont, numberFont = false, false

filename = "ichdrehdurchcounter.txt"
counter = 0
errorlol = false

buttons = {
    decrease = width/5,
    increase = (width/5)*3,
    y = ((height/8)*7)-30,
    w = width/4,
    h = (height/10)
}

function saveFile()
    succ = love.filesystem.write(filename, counter)
    if succ then
        love.system.vibrate(0.1)
    end
end

function love.load()
    if love.system.getOS() == "Linux" then
        width, height = height, width
    end
    textFont = lg.newFont(80)
    numberFont = lg.newFont(200)
    lg.setFont(textFont)

    contents = love.filesystem.read(filename)
    errorlol = contents == nil
    if not errorlol then
        counter = tonumber(contents)
    else
        succ = love.filesystem.write(filename, counter)
        errorlol = not succ
    end
end

function love.update( dt ) end

function love.draw()
    if errorlol then
        lg.print("Error while loading the counter file", 100, 100)
    else
        lg.setColor(1, 1, 1)
        lg.setFont(numberFont)
        text, tx, ty = centerText(tostring(counter), numberFont, height/2 - 50)
        lg.print(text, tx, ty)
        lg.setLineWidth(2)
        lg.line(width/2 - (numberFont:getWidth(text)/2), height/2 + 50, width/2 + (numberFont:getWidth(text)/2), height/2 + 50)

        lg.setFont(textFont)
        text, tx, ty = centerText('"ich dreh durch"', textFont, height/3)
        lg.print(text, tx, ty)
        
        lg.setLineWidth(5)
        lg.rectangle("line", buttons.decrease, buttons.y, buttons.w, buttons.h)
        lg.rectangle("line", buttons.increase, buttons.y, buttons.w, buttons.h)
        lg.setColor(0.1, 0.1, 0.1)
        lg.rectangle("fill", buttons.decrease, buttons.y, buttons.w, buttons.h)
        lg.rectangle("fill", buttons.increase, buttons.y, buttons.w, buttons.h)

        lg.setFont(textFont)
        lg.setColor(1, 1, 1)
        text, tx, ty = centerTextInButton("-", textFont, buttons.decrease, buttons.y)
        lg.print(text, tx, ty)
        text, tx, ty = centerTextInButton("+", textFont, buttons.increase, buttons.y)
        lg.print(text, tx, ty)
    end
end

function centerText(text, font, y)
    return text,
        (width / 2) - (font:getWidth(text) / 2),
        y - (font:getHeight(text) / 2)
end

function centerTextInButton(text, font, x, y) -- returns text, x, y
    return text,
        x + ((buttons.w/2)-((font:getWidth(text)/2))),
        y + ((buttons.h/2)-((font:getHeight(text)/2)))
end

function inArea(mx, my, bx)
    return mx > bx and mx < bx+buttons.w and my > buttons.y and my < buttons.y+buttons.h
end

function love.mousepressed( x, y, button, istouch, presses )
    if inArea(x, y, buttons.decrease) then
        counter = counter - 1
        saveFile()
    elseif inArea(x, y, buttons.increase) then
        counter = counter + 1
        saveFile()
    end
end