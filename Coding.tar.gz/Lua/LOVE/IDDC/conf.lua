function love.conf(t)
    t.window.usedpiscale = false
    t.window.width = 800
    t.window.height = 1000

    t.modules.joystick = false
    t.modules.physics = false
    t.modules.audio = false
    t.modules.sound = false
    t.modules.thread = false
    t.modules.video = false
end