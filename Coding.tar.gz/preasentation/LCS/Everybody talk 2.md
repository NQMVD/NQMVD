we all say shit about our stuff from left to right and David ends with "und das alles wird als Endabgabe in ein Program packen" or smth


Samuel: 
Ich erstelle eine Feuersimulation die ohne probleme mit 60 fps feuer verschiedener arten und farben generieren kann.

Jedes partikel hat eine wärme variable die bestimmt mit welcher geschwindigkeit es sich nach oben bewegt.

Partikel die sich berühren normalisieren ihre wärme zwischen sich.

Der Boden gibt wärme von sich.

Je wärmer ein Partikel ist desto stärker wird ihre farbe dargestellt.

Die farbe wird einstellbar sein damit man nicht nur orange sondern auch andere Feuer simulieren kann.

Man wird auch zwischen verschiedenen gravitationsarten auswählen können um z.B einen "feuerball" haben zu können.


David:
Ich erstelle eine Flüssigkeitensimulation die verschiedene arten von flüssigkeiten wie wasser, honig und öl simulieren kann.

Man kann die farbe der flüssigkeiten einstellen, was sie für eine Dichte haben und wie schnell sie aus dem Schlauch raus kommt.

Es gibt 2 flüssigkeiten. Die erste ist bereits im Bild und reagiert auf die bewegung der zweiten flüssigkeit, welche aus dem schlauch gedrückt wird. 

Durch verschiedene geschwindigkeiten, farben und dichten vermischen sich dann die flüssigkeiten in einer schön anzusehenden art