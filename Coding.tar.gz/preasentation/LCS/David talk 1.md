Explain what we are doin now

Jeder macht ein eigenes "mini-Projekt"
Noah macht einen Partikelsimulator
Samuel macht einen Feuersimulator
Ich mache einen Flüssigkeitssimulator