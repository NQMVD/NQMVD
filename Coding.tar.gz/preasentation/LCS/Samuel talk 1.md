explain what LÖVE is

LÖVE is eine game engine für lua

Einfach zu lernen
Unterstützt PC, Web und Android

