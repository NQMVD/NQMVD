require "lib.noahsutils"
require "classes"

-- prinspect(initializePIN(1000))

local test = constructAND(100, 200, 3)

prints(constructINPUT(100, 200))