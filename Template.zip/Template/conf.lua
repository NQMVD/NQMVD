function love.conf(t)
    t.title = "Test"
    t.author = "Template"

    t.window.width, t.window.height = 1280, 720
    -- t.window.width, t.window.height = 1920, 1080

    t.modules.audio = false
    t.modules.joystick = false
    t.modules.physics = false
    t.modules.sound = false
    t.modules.touch = false
end