io.stdout:setvbuf("no")
inspect = require "lib.inspect"
Collection = require "lib.collections"

function prinspect(...) print(inspect(...)) end
function printf(...) print(string.format(...)) end

timeRecordsTable = collect{}

function startTimeRecord(name_)
	local firstIndex = timeRecordsTable:search(function(key, value) return value.name == name_ end)
	if type(firstIndex) == "number" then
		timeRecordsTable.table[firstIndex].duration = 0
		timeRecordsTable.table[firstIndex].endTime = 0
		timeRecordsTable.table[firstIndex].startTime = love.timer.getTime()
	else
		timeRecordsTable:append{ name=name_, startTime=love.timer.getTime(), endTime=0, duration=0 }
	end
end

function stopTimeRecord(name_)
	local time = love.timer.getTime()
	local firstIndex = timeRecordsTable:search(function(key, value) return value.name == name_ end)
	if type(firstIndex) == "number" then
		timeRecordsTable.table[firstIndex].endTime = time
		timeRecordsTable.table[firstIndex].duration = time - timeRecordsTable.table[firstIndex].startTime
	end
end

function printTimeRecords()
	timeRecordsTable:each(function(key, value) printf("'%s' took %.3fms", value.name, value.duration*1000) end)
end

function nfc(num)
    return tostring(num):reverse():gsub("%d%d%d", "%1,"):reverse():gsub("^,", "")
end

function eucdist(x1, y1, x2, y2)
    return math.sqrt((x2-x1)^2 + (y2-y1)^2)
end

function mandist(x1, y1, x2, y2)
    return math.abs(x2 - x1) + math.abs(y2 - y1)
end

function map(value, start1, stop1, start2, stop2)
     return start2 + (stop2 - start2) * ((value - start1) / (stop1 - start1));
end

function constrain(value, start, stop)
    if value > stop then return stop
    elseif value < start then return start
    else return value end
end
