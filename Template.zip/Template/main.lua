--=================================[ imports ]======================================--

require "lib.noahsutils"

--================================[ variables ]=====================================--



--============================[ main functions ]=================================--

function love.load()

end

function love.update(dt)

end

function love.draw()

end

function love.quit()

end

--=============================[ input functions ]==================================--

function love.mousepressed(x, y, button) end

function love.mousereleased(x, y, button) end

function love.wheelmoved(dx, dy) end

function love.keypressed(key, unicode) end

--=============================[ custom functions ]=================================--
